import sqlite3

# Connect to the database
con = sqlite3.connect("mydb.db")
cur = con.cursor()

# Create the history table
cur.execute("""
    CREATE TABLE IF NOT EXISTS history (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        task_name TEXT,
        task_date DATE
    )
""")

# Commit the transaction and close the connection
con.commit()
con.close()
